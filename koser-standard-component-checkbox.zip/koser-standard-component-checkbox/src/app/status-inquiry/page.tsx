import { CommonLayout } from "@components/layout";

export default function StatusInquiry() {
  return (
    <CommonLayout>
      <div>현황조회</div>
    </CommonLayout>
  );
}