import {
  getAirlineData,
  getPassengerListData,
  postAirlineData,
} from "@services/main";

export default async function Home() {
  const sampleId = "73dd5420-3bf9-48f3-a0b6-17cf7aa61b19";
  const { data: airlineData } = await getAirlineData(sampleId);

  const { data: passengerListData } = await getPassengerListData({
    page: 1,
    size: 10,
  });

  const sampleObj = {
    _id: "000",
    name: "한국항공",
    country: "대한민국",
    logo: "",
    slogan: "",
    head_quarters: "서울",
    website: "",
    established: "2025",
  };

  const { data: addedAirlineData } = await postAirlineData(sampleObj);

  console.log(airlineData);
  console.log(passengerListData);
  console.log(addedAirlineData);

  return (
    <main>
      <div>main</div>
    </main>
  );
}
