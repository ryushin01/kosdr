import { CommonLayout } from "@components/layout";

export default function Dashboard() {
  return (
    <CommonLayout>
      <div>대시보드</div>
    </CommonLayout>
  );
}