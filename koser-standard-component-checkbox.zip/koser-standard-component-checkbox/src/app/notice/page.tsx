import { CommonLayout } from "@components/layout";

export default function Notice() {
  return (
    <CommonLayout>
      <div>공지사항</div>
    </CommonLayout>
  );
}