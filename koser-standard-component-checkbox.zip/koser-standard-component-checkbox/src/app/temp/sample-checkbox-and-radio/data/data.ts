export const SAMPLE_DATA_LIST = [
  {
    id: 1,
    name: "option1",
    labelText: "1번",
    checked: false,
    disabled: false,
  },
  {
    id: 2,
    name: "option2",
    labelText: "2번",
    checked: false,
    disabled: false,
  },
  {
    id: 3,
    name: "option3",
    labelText: "3번",
    checked: false,
    disabled: false,
  },
  {
    id: 4,
    name: "option4",
    labelText: "4번",
    checked: false,
    disabled: false,
  },
  {
    id: 5,
    name: false,
    labelText: "5번",
    checked: false,
    disabled: true,
  },
];