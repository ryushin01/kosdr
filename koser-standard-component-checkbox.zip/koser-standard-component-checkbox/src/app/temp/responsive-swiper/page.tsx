"use client";

import { ResponsiveSwiper } from "@components/common";

export default function ResponsiveSwiperPage() {
  return (
    <>
      <ResponsiveSwiper className="등기자료" />
      <ResponsiveSwiper className="등기접수증" />
    </>
  );
}
