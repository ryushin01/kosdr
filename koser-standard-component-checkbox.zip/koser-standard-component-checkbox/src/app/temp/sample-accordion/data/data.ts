export const ACCORDION_DATA_LIST = [
  {
    id: 1,
    title: "공지사항 제목1",
    author: "홍길동",
    date: "20250211",
    description: "공지사항 내용",
  },
  {
    id: 2,
    title: "공지사항 제목2",
    author: "류창선",
    date: "20250211",
    description: "집에 가고 싶어요",
  },
];