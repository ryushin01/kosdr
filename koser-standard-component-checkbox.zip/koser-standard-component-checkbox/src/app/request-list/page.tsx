import { CommonLayout } from "@components/layout";

export default function RequestList() {
  return (
    <CommonLayout>
      <div>의뢰목록</div>
    </CommonLayout>
  );
}