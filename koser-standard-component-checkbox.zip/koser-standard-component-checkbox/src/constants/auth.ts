export const AUTH_LIST = [
  { id: 1, name: "auth", value: "institution", labelText: "금융기관", disabled: false },
  {
    id: 2,
    name: "auth",
    value: "representative",
    labelText: "법무대리인",
    disabled: false,
  },
  {
    id: 3,
    name: "auth",
    value: "administrator",
    labelText: "관리자",
    disabled: false,
  },
  {
    id: 4,
    name: "auth",
    value: "tester",
    labelText: "테스터",
    disabled: true,
  },
];