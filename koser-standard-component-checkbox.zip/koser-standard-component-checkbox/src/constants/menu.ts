export const MENU_LIST = [
  {
    id: 1,
    name: "대시보드",
    path: "/dashboard",
  },
  {
    id: 2,
    name: "의뢰목록",
    path: "/request-list",
  },
  {
    id: 3,
    name: "현황조회",
    path: "/status-inquiry",
  },
];