export const appURI = process.env.NEXT_PUBLIC_APP_URI;

export const adminURI = process.env.NEXT_PUBLIC_ADMIN_URI;

export const apiURI = process.env.NEXT_PUBLIC_API_URI;

export const fakeURI = process.env.NEXT_PUBLIC_FAKE_URI;