export const TITLE = "KOSER STANDARD :: 신협 전자등기 프로젝트";

export const DESCRIPTION = "신협 전자등기 프로젝트";

export const FAVICON = "/logo.svg";

export const OG_IMAGE = "/og_images.png";