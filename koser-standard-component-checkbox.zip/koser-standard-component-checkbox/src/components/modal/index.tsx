import Modal from "@components/modal/Modal";
import ModalHeader from "@components/modal/ModalHeader";
import ModalFooter from "@components/modal/ModalFooter";

export {
  Modal,
  ModalHeader,
  ModalFooter,
};