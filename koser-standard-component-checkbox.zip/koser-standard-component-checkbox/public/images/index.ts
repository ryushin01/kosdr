import SpinnerImage from "./spinner.svg";

export {
  SpinnerImage,
};
